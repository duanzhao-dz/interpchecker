InterpChecker
====================================


InterpChecker is built upon CPAChecker. Thus all the commands of InterpChecker are the same with CPAChecker.


InterpChecker supports the verification of reachability of C programs instrumented with  the property file ReachSafety.prp  (CHECK ( init(main()) , LTL (G ! (__VERIFIER_error())) )) 
                                           
To conduct verification tasks with InterpChecker, the following command should be used:
 
           scripts/cpa.sh -skipRecursion -config config/sv-comp18-interpcpachecker.properties  -spec  ReachSafety.prp  <source file>
  
           

                                           
