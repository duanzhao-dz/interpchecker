int main(){
  int x;
  int y;
  if(y>2){
    x=1;
  }
  else{
    x=3;
  } 
  if(x>0){
    __VERIFIER_error();
  } 
  return 0;
}
