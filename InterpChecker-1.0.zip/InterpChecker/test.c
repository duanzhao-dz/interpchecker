int main(){
   int x;
   int i;
   if(x>2){
     i=1;
   }
   else{
     i=3;
   }
   if(i>1){
    __VERIFIER_error();
   }
   return 0;
}
