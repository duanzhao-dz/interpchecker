void __VERIFIER_error();
void err();
int *return_self(int *p);
int main();
extern void __VERIFIER_error(void);
int main_0();
int *return_self_1(int *p);
void err_2();
int main_0() {
  int a;
  int *q;
  a = 1;
  q = return_self_1(&a);
  *q = 2;
  __CPROVER_assume(a == 2);
  err_2();
}

int *return_self_1(int *p) {
  return p;
}

void err_2() {
  __VERIFIER_error(); // target state
  __VERIFIER_error();
}
