This directory contains configuration files
with analyses that are not mean to be executed on their own
but inside a sequential combination of analyses.
Typically these configuration contain some low resource limit
or other restriction that would not be present in a normal configuration file.
