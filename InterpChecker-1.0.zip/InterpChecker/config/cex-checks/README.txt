This directory contains configuration files
that configurations targeted for counterexample checks
with analysis.checkCounterexamples=true.
