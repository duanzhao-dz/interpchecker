This directory contains configuration files
that are only meant to be included from other configuration files
and do not contain a full usable configuration on their own.
