int f(int x);
int main();
extern void __VERIFIER_error(void);
int main_0();
int f_1(int x);
int main_0() {
  int x;
  int y;
  x = 1;
  y = f_1(x);
  __CPROVER_assume(!(y > 2));
  x = y + 3;
  __CPROVER_assume(x > y);
  __VERIFIER_error(); // target state
}

int f_1(int x) {
  __CPROVER_assume(x > 0);
  int __CPAchecker_TMP_0;
  __CPAchecker_TMP_0 = f(x);
  return __CPAchecker_TMP_0;
}
