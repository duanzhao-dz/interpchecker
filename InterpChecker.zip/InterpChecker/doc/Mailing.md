The CPAchecker Project uses the following mailing lists:

- CPAchecker-Announce@googlegroups.com
  Announcements about the CPAchecker project.
  Read-only, anyone can join, low traffic volume.
  https://groups.google.com/forum/#!forum/cpachecker-announce

- CPAchecker-Users@googlegroups.com
  User discussion, questions, solutions to common problems.
  Members can post, anyone can join.
  https://groups.google.com/forum/#!forum/cpachecker-users

- CPAchecker-Commits@googlegroups.com
  Archive of commit messages from the CPAchecker repository.
  Read-only, by invitation only, high volume.
  https://groups.google.com/forum/#!forum/cpachecker-commits

- CPAchecker-Devel@googlegroups.com
  Internal developer discussion about the design and implementation of CPAchecker.
  Only for active developers (>0 cpm), members can post, by invitation only.
  https://groups.google.com/forum/#!forum/cpachecker-devel
