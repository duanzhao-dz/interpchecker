int f(int x){
  if(x>0){
   return f(x);
  }
  x=x-1;
  return x;
}
int main(){
   int x;
   int y;
   x=1;
   y=f(x);
   if(y>2){
     y=x+2;
   }
   else{
     x=y+3;
   }
   if(x>y){
     ERROR:__VERIFIER_error();
   }
   return 0;
 
}